# Dominguez Electric: concept website

Static site (HTML, CSS, JavaScript). No build step and no dependencies.

## Structure
- `index.html` the page
- `assets/css/styles.css`, `assets/js/main.js`
- `assets/img/` WebP photos (hero and van have two sizes each)
- `vercel.json` headers and caching; `favicon.svg`

## Run locally
Open `index.html` in a browser, or run `npx serve .`

## Deploy: GitHub + Vercel
1. Create a GitHub repository and push this folder (`git init`, `git add .`, `git commit -m "Initial site"`, then add the remote and push).
2. In Vercel choose **Add New > Project**, import the repository.
3. Framework Preset: **Other**. Leave Build Command and Output Directory empty. Deploy.

## Before going public
- The page has `<meta name="robots" content="noindex, nofollow">` because it is an independent design concept, not the company's official site. Delete that line only with the owner's approval.
- Items marked "to be confirmed" (license, insurance, years in business, email, other cities, company history) need verified information.
- The two electrician photos are stock images, the van and project photos come from Google Maps contributors, and the review excerpts come from public Google reviews. Get permission or replace them before commercial use.
- The estimate form is a front-end demo and sends nothing. Connect it to a form service before launch.
- If you replace a photo, keep the file name and expect up to a week of browser caching, or rename the file and update `index.html`.
