/* Dominguez Electric concept site: menu, reveal-on-scroll, nav highlight, review carousel, form validation. */
(function () {
  'use strict';
  var reduce = window.matchMedia('(prefers-reduced-motion: reduce)');
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };

  /* Mobile menu */
  var mb = $('#mb'), menu = $('#menu');
  function closeMenu() { menu.classList.remove('open'); mb.setAttribute('aria-expanded', 'false'); }
  mb.addEventListener('click', function () {
    mb.setAttribute('aria-expanded', String(menu.classList.toggle('open')));
  });
  menu.addEventListener('click', function (e) { if (e.target.closest('a')) closeMenu(); });
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape' && menu.classList.contains('open')) { closeMenu(); mb.focus(); }
  });

  /* Reveal on scroll and active nav link: IntersectionObserver only, no scroll listeners */
  var items = $$('.reveal');
  if ('IntersectionObserver' in window) {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (x) {
        if (x.isIntersecting) { x.target.classList.add('in'); io.unobserve(x.target); }
      });
    }, { rootMargin: '0px 0px -8% 0px' });
    items.forEach(function (el) { io.observe(el); });

    var links = $$('#menu a');
    var spy = new IntersectionObserver(function (entries) {
      entries.forEach(function (x) {
        if (!x.isIntersecting) return;
        links.forEach(function (l) {
          if (l.getAttribute('href') === '#' + x.target.id) l.setAttribute('aria-current', 'true');
          else l.removeAttribute('aria-current');
        });
      });
    }, { rootMargin: '-45% 0px -50% 0px' });
    ['residential', 'commercial', 'about', 'reviews', 'contact'].forEach(function (id) {
      var s = document.getElementById(id); if (s) spy.observe(s);
    });
  } else {
    items.forEach(function (el) { el.classList.add('in'); });
  }

  /* Review carousel */
  var track = $('#track');
  function scrollReviews(dir) {
    track.scrollBy({ left: dir * track.clientWidth * 0.8, behavior: reduce.matches ? 'auto' : 'smooth' });
  }
  $('#rp').addEventListener('click', function () { scrollReviews(-1); });
  $('#rn').addEventListener('click', function () { scrollReviews(1); });

  /* Review dates are approximate; shown as relative time */
  function rel(d) {
    var n = Math.round((Date.now() - new Date(d)) / 864e5);
    if (n < 14) return 'Recently';
    if (n < 30) return Math.round(n / 7) + ' weeks ago';
    var m = Math.round(n / 30.4);
    return m < 12 ? m + (m > 1 ? ' months ago' : ' month ago') : 'Over a year ago';
  }
  $$('time[data-d]').forEach(function (x) { x.textContent = rel(x.getAttribute('data-d')); });

  /* "Read more": batch layout reads, then writes, once per frame */
  var cards = $$('.gc'), queued = 0;
  function checkClamp() {
    queued = 0;
    var need = cards.map(function (c) { var p = $('.gt', c); return p.classList.contains('open') || p.scrollHeight > p.clientHeight + 2; });
    cards.forEach(function (c, i) { $('.rm', c).hidden = !need[i]; });
  }
  function schedule() { if (!queued) queued = requestAnimationFrame(checkClamp); }
  cards.forEach(function (c) {
    var p = $('.gt', c), b = $('.rm', c);
    b.addEventListener('click', function () {
      var open = p.classList.toggle('open');
      b.textContent = open ? 'Show less' : 'Read more';
      b.setAttribute('aria-expanded', String(open));
    });
  });
  checkClamp();
  window.addEventListener('load', schedule);
  window.addEventListener('resize', schedule, { passive: true });
  if (document.fonts && document.fonts.ready) document.fonts.ready.then(schedule);

  /* Estimate form (front-end demo: nothing is sent) */
  var f = $('#f');
  function valid(el) {
    var v = el.value.trim();
    if (!v) return !el.required;
    if (el.type === 'email') return /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(v);
    if (el.type === 'tel') return v.replace(/\D/g, '').length >= 10;
    return true;
  }
  f.addEventListener('submit', function (e) {
    e.preventDefault();
    var good = true;
    $$('[data-f]', f).forEach(function (w) {
      var i = $('input,select,textarea', w), v = valid(i);
      w.classList.toggle('bad', !v);
      i.setAttribute('aria-invalid', String(!v));
      if (!v) good = false;
    });
    var bad = $('.bad input,.bad select,.bad textarea', f);
    if (bad) bad.focus();
    $('#ok').style.display = good ? 'block' : 'none';
    if (good) f.reset();
  });
})();
